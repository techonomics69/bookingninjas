# Gulp Starter

Remember to do run the `npm install` command after cloning this repo.
After that use `gulp` command to watch your changes. 